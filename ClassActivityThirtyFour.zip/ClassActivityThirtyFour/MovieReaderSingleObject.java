package ClassActivityThirtyFour;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MovieReaderSingleObject {
    public static void main(String[] args) {
        try{
            Gson gson = new Gson();
            BufferedReader reader = new BufferedReader(new FileReader("MovieTheater.json"));
            MovieTheaterReservation movieTheaterReservation = gson.fromJson(reader,MovieTheaterReservation.class);
            System.out.println("****** Movie Theater Reservation Details ******");
            System.out.printf("Customer Name: %s\nMovie Title: %s\nReservation ID: %d\nSeat Number: %d", movieTheaterReservation.getCustomerName(), movieTheaterReservation.getMovieTitle(), movieTheaterReservation.getReservationID(), movieTheaterReservation.getSeatNumber());
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
