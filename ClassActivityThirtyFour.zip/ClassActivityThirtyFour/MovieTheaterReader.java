package ClassActivityThirtyFour;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

public class MovieTheaterReader {
    public static void main(String[] args) {
        try {
            Gson gson = new Gson();
            BufferedReader reader = new BufferedReader(new FileReader("Movies.json"));
            Type movieListType = new TypeToken<List<MovieTheaterReservation>>() {}.getType();

            List<MovieTheaterReservation> movieList = gson.fromJson(reader, movieListType);
            System.out.println("****** Movie Reservation Details ******");

            for (MovieTheaterReservation reservation : movieList) {
                System.out.printf("Movie Title: %s\nCustomer Name: %s\nReservation ID: %d\nSeat Number: %d", reservation.getMovieTitle(), reservation.getCustomerName(), reservation.getReservationID(), reservation.getSeatNumber());
                System.out.println(" ");
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}