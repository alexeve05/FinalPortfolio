package ClassActivityThirtyFour;

import com.google.gson.Gson;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTheaterWriter {
    public static void main(String[] args) {
        try{
            MovieTheaterReservation movieInfo = new MovieTheaterReservation("Alexis", "Cars", 200519, 23);
            Gson gson = new Gson();

            String jsonString = gson.toJson(movieInfo);
            System.out.println(jsonString);

            FileWriter filewriter = new FileWriter("MovieTheater.json");
            filewriter.write(jsonString);
            filewriter.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
