package ClassActivityThirtyFour;

public class MovieTheaterReservation {
    private int reservationID, seatNumber;
    private String customerName, movieTitle;
    private static int instanceCount = 0;

    MovieTheaterReservation(){
        instanceCount++;
    }
    MovieTheaterReservation(String customerName, String movieTitle, int reservationID, int seatNumber){
        this.customerName = customerName;
        this.movieTitle = movieTitle;
        this.reservationID = reservationID;
        this.seatNumber = seatNumber;
        instanceCount++;
    }

    //getters
    public String getCustomerName(){
        return customerName;
    }
    public String getMovieTitle(){
        return movieTitle;
    }
    public int getReservationID(){
        return reservationID;
    }
    public int getSeatNumber(){
        return seatNumber;
    }

    //setters
    public void setCustomerName(String customerName){
        this.customerName = customerName;
    }
    public void setMovieTitle(String movieTitle){
        this.movieTitle = movieTitle;
    }
    public void setReservationID(int reservationID){
        this.reservationID = reservationID;
    }
    public void setSeatNumber(int seatNumber){
        this.seatNumber = seatNumber;
    }

    //display
    public void showDetails(){
        System.out.println("The movie theater reservation information you entered includes: ");
        System.out.println("Customer name: " + customerName);
        System.out.println("Movie title: " + movieTitle);
        System.out.println("Reservation ID: " + reservationID);
        System.out.println("Seat Number: " + seatNumber);
        System.out.println("Enjoy your movie!");
    }

    public static int getInstanceCount(){
        return instanceCount;
    }
}
